PSGTool

This program is distributed under the attached license. See License.txt.

=======================
Required Runtimes
=======================
Java 6 or newer:
http://www.java.com

=======================
Usage
=======================
java -jar PSGTool.jar INPUTFILE [OUTPUTFILE] [2|3|23] [OPTIONS]
Options:
- split           Split large files into multiple files.
- uncompressed    Don't compress output.
- framerate       The target framerate. E.g. 60 for NTSC. If not specified, the input framerate is used.