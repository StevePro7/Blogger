MoonBlaster v1.4 development package
====================================

WHAT'S THIS THEN?

This package contains all sources of the MoonBlaster v1.4 versions. With this
package and some programming skills you can recreate all the executable code!
For your convenience, even more interesting thingies are included in this
package. It contains:
- README.TXT   This readme ;-)
- MB14SRC.PMA  All sources for MoonBlaster v1.4
- MB14PLY.PMA  All sources for the MB BASIC replayer

So, all in all, IMHO this is one of the most interesting packages for MSX
programmers that ever released!


COOL! BUT WHY?!

It is a well-known fact that programmers usually are not very fond of spreading
the sources they worked on for many hours. The talented programmers claim that
they don't want others to be able to use their 'exclusive and fabulous' code.
Other programmers are afraid that their code is a bit of a mess and may feel a
bit embarrassed, even if they will of course always proclaim the 'exclusive
code' statement ;-) So, why this exception?

Well, I have a number of reasons for doing this. First of all, I have enjoyed
programming for my MSX for many years and it has always been a major part of
my life. However, just as everyone else I have the unpleasent experience of
getting older. During this process I graduated, got a job and was even so
lucky to find a girl who (for reasons still uncomprehended) likes me. These
are all very nice things and you will never hear me complaining about my life.
Unfortunately for the MSX scene, all of these things swallow up huge hogs of
time and to my regret I hardly have any spare time. And the little spare time
that I have left will not be spent programming since that is part of my current
job as a software engineer from 9 to 5...

I used to be an important MSX programmer, especially when it comes to music
programs, replay routines or other related stuff. And many people have asked
me lately if I will ever make a new version of (some) MoonBlaster and if so,
if I would be so kind to built such-and-such feature into the new release.
So this package is my final answer to everyone:

--- No, I will never make a new MSX release of MoonBlaster! ---

The reasons are stated above.
But I still have many good memories about MSX and I want to encourage people
to continue their programming efforts to get the utmost out of that great
MSX thingy they have on their desk. My goal with this package was that it can
and probably will be interesting for many programmers:

- You can study the source code to learn about MSX-MUSIC/MSX-AUDIO programming
  or programming in general.
- You can modify and likely even improve the programs and make even more
  incredible music.
- You can have a good laugh about the mess in some portions of the code ;-)
  Well, since this is one of my first projects, replace that with *most*
  portions of the code ;-)


WHAT DO I NEED TO GET THINGS GOING?

Not much that every MSX programmer shouldn't already have:
- MSX-DOS (DOS2 and harddisk preferred)
- GEN80
- A good ASCII text editor like TED
- 256K RAM (Believe me, you don't want to use things with 128K and DOS1)
- Enough programming talent
- An MSX-MUSIC / MSX-AUDIO (well, not really but you probably want to hear some of the
  results of your work ;-)


NOW, THE NASTY STUFF...

All good things have some drawbacks. With the release of this package I took
the risk of getting loads and loads of MSX programmers rapid-firing all kinds of
questions at me about its contents. That's why you the following limitations and
rules apply to the use of this package:

1) First of all, the standard disclaimer. I don't take any responsibility for
any damage or misfortune you may have as the result of the use of this package.

2) It is allowed to use the MoonBlaster sources for a new music program that
is spread as public domain. You are allowed to create a new music
program or extend MoonBlaster with these sources.

3) I will NOT answer any questions related to the contents of this package. So
NEVER bother me with programming questions why I put such-and-such a routine
in the program or other annoying quesions. This package contains everything you
need so if you don't understand it: Study hard and become a better programmer...


FAMOUS LAST WORDS

Ok, after reading this message I realize that parts of it sound very unfriendly,
but I hope you can understand my position. For years many people called me with
their questions and I have always tried my best to help them in any way. But
lately I just haven't had the time or possibility to do so.

Does this heading mean that I will be completely gone concerning MSX? Well,
that's a toughy to answer. I could state a fancy story here like many MSX groups
did about not completely quitting MSX but just doing less ant then slowly
diminish into a bit nothing. But I prefer to be honest: Yes, probably. I still
have my MSX fully operational and ready-to-run and I will very likely enjoy some
of the game classics or new things that might be released but it is not very
likely that I will release a new program or do any other MSX stuff that will put
me back in the MSX-scene.

But, never say never and maybe you will hear from me again. I wish you MSX guys
all the best and I hope I did at least a few people a great favour with this
package.

See ya!

Remco Schrijvers / MoonSoft			   (Date: March 30, 1997)

Restrictions on using the sources to create new music programs or extend 
MoonBlaster and the option to ask questions by e-mail removed. 
(Date: July 1, 2012)

Missing part of sources recreated by NYYRIKKI (Date: July 3, 2012)
